.. Hamiltonian_Solver documentation master file, created by

   sphinx-quickstart on Thu Mar 23 14:16:54 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Hamiltonian_Solver's documentation!
==============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   

Homework8
****************
.. automodule:: Homework8.homework8
   :members:

test
****************
.. automodule:: Homework8.test
   :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
